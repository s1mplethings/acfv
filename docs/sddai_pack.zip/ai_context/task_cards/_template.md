# Task Card: <title>

## Context
- 为什么要做？

## Scope
- In scope:
- Out of scope:

## Acceptance Criteria
- AC-1:
- AC-2:

## Files touched (expected)
- ...

## Verify
- Linux/macOS: `bash scripts/verify.sh`
- Windows: `powershell -ExecutionPolicy Bypass -File scripts/verify.ps1`

## Verify log
- PASS/FAIL + 关键输出片段

## Notes / Follow-ups
- ...
