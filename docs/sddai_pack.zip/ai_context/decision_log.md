# Decision Log（临时偏离 / 豁免记录）

> 规则：任何临时豁免或“先不做/先跳过”的决定必须记录，并附补齐计划。

---

## <YYYY-MM-DD> - <decision title>
- Context：
- Decision：
- Why：
- Scope：
- Follow-up plan（补齐计划）：
- Owner：
