Param(
  [switch]$SkipContractChecks
)

$ErrorActionPreference = "Stop"

Write-Host "[verify] OS: Windows"
Write-Host "[verify] Running: unit/integration/e2e (project-defined) + contract checks"
Write-Host ""

# NOTE: This is a template. Replace the commands below with your repo's actual tooling.
# Examples:
# python -m compileall -q src
# python -m pytest -q

python -c "print('[verify] python ok')" | Out-Host

if (-not $SkipContractChecks) {
  python scripts/contract_checks.py | Out-Host
}

Write-Host ""
Write-Host "[verify] PASS"
