#!/usr/bin/env bash
set -euo pipefail

echo "[verify] OS: $(uname -s)"
echo "[verify] Running: unit/integration/e2e (project-defined) + contract checks"
echo

# NOTE: This is a template. Replace the commands below with your repo's actual tooling.
# Examples:
# python -m compileall -q src
# python -m pytest -q
# python scripts/contract_checks.py

if command -v python >/dev/null 2>&1; then
  python -c "print('[verify] python ok')"
else
  echo "[verify] ERROR: python not found" >&2
  exit 2
fi

python scripts/contract_checks.py

echo
echo "[verify] PASS"
