#!/usr/bin/env python
from __future__ import annotations

import json
from pathlib import Path

# contract_checks.py (template)
#
# 目的：
# - 把“输出契约”从文档约定变成自动失败的质量门（见 docs/03_quality_gates.md）。
#
# 当前实现只做“最小必须项”的演示：
# - 校验仓库中若存在约定的示例/产物文件时，是否包含 schema_version。
# 你可以按需扩展：校验排序、时间戳边界、manifest 映射等。

CANDIDATE_PATHS = [
    Path("runs") / "out" / "segments.json",
    Path("runs") / "out" / "clips_manifest.json",
    Path("work") / "segments.json",
    Path("work") / "clips_manifest.json",
]

def check_schema_version(p: Path) -> list[str]:
    errs: list[str] = []
    try:
        obj = json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        return [f"{p}: JSON parse error: {e}"]
    if not isinstance(obj, dict):
        return [f"{p}: expected object"]
    if "schema_version" not in obj:
        errs.append(f"{p}: missing schema_version")
    return errs

def main() -> int:
    existing = [p for p in CANDIDATE_PATHS if p.exists()]
    if not existing:
        print("[contract_checks] no known artifact files found (ok for template)")
        return 0

    errors: list[str] = []
    for p in existing:
        errors.extend(check_schema_version(p))

    if errors:
        print("[contract_checks] FAIL")
        for e in errors:
            print(" -", e)
        return 1

    print("[contract_checks] PASS")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
